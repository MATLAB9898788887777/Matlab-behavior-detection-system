function biaoshi
%figure;
k=25;
mkdir('result');
while(k<300)
    %��ȡ������
    
    beijing=imread(['Xmt\',num2str(k+10),'.jpg']);
    mubiao=imread(['Xmt\',num2str(k+12),'.jpg']);
    bw_img2=rentiGJ(beijing,mubiao);
    beijing=imread(['Xmt\',num2str(k),'.jpg']);
    mubiao=imread(['Xmt\',num2str(k+2),'.jpg']);
    bw_img=rentiGJ(beijing,mubiao);
    %����������Ϣ
    [xx,yy,length,heigth,total,zyy]=biaozhu(bw_img);
    [xx2,yy2,length2,heigth2,total2,zyy2]=biaozhu(bw_img2);
    
    
    if(total<300000)
        %״̬�ж�
        bili=abs(heigth/length);
        if ((bili<=1)&&(10<=(zyy2-zyy)))
            b='����';
        else
            b='����';
        end
        
        %��ע״̬
        image(mubiao);
        if(strcmp(b,'����'))
            text1=text(xx,yy,['״̬��',b,'��']);
            set(text1,'Color','R','FontWeight','demi');
        else
            text1=text(xx,yy,['״̬��',b,'��']);
            set(text1,'Color','G','FontWeight','demi');
        end
        %  rectangle('position',[xx,yy,length,heigth],'edgecolor','r');
        
        %������
        saveas(gcf,['result\',num2str(k+1),'.jpg']);
    end
    
    k=k+20;
end
